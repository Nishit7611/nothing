# garak/agent.py
"""
Garak ADK agent that uses LiteLLM → Ollama → Mistral 

Prereqs
-------
1.  pip install -U litellm
2.  ollama pull mistral    # make sure this model is locally available
3.  adk web                         # from your project root
"""

import asyncio
import logging
from typing import Dict, Any

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm     # LiteLLM wrapper

from . import model                                # your model.py helpers

logger = logging.getLogger(__name__)

# ────────────────────────────────────────────────────────────
# Build a LiteLLM wrapper that points at Ollama’s Mistral-Small 3.1
# ────────────────────────────────────────────────────────────
ollama_wrapper = LiteLlm(
    model="ollama_chat/mistral:latest",
    parameters={
        "api_base": "http://localhost:11434",
        "stream": False
    },
)

# In-memory scan state (for demo purposes)
active_scans: Dict[str, Dict[str, Any]] = {}


class GarakAgent(LlmAgent):
    """
    Garak vulnerability-scanning agent.

    Uses LiteLLM → Ollama → Mistral under the hood.
    """

    def __init__(self) -> None:
        super().__init__(
            model=ollama_wrapper,   # LiteLLM instance from above
            name="garak_agent",
            description="Garak vulnerability scanner (Mistral via Ollama)",
            instruction=(
                "Commands (exactly one per message):\n"
                "  list             – show available probes\n"
                "  scan <probe>     – start a new scan\n"
                "  status <scan_id> – check scan status"
            ),
        )

    async def on_message(self, message) -> str:
        cmd = message.text.strip().lower()

        # ── list ──
        if cmd == "list":
            return "Available probes:\n" + ", ".join(model.PROBES)

        # ── scan <probe> ──
        if cmd.startswith("scan "):
            probe = cmd[5:].strip()
            if probe not in model.PROBES:
                return "❌ Invalid probe. Send “list” to see available probes."
            scan_id = f"scan_{len(active_scans)}"
            active_scans[scan_id] = {"probe": probe, "status": "queued"}
            asyncio.create_task(_run_scan(scan_id, probe))
            return (
                f"🚀 Started {scan_id} ({probe}).\n"
                f"Send “status {scan_id}” to check progress."
            )

        # ── status <scan_id> ──
        if cmd.startswith("status "):
            scan_id = cmd[7:].strip()
            info = active_scans.get(scan_id)
            if not info:
                return "❌ No such scan ID."
            if info["status"] == "completed":
                return (
                    f"✅ {scan_id} done.\n"
                    f"Probe : {info['probe']}\n"
                    f"Result: {info['result']}"
                )
            if info["status"] == "failed":
                return f"⚠️  {scan_id} failed: {info['error']}"
            return f"⏳ {scan_id} is {info['status']}"

        # ── fallback/help ──
        return (
            "Commands (exactly one per message):\n"
            "  list             – show available probes\n"
            "  scan <probe>     – start a new scan\n"
            "  status <scan_id> – check scan status"
        )


async def _run_scan(scan_id: str, probe: str, use_gpu: bool = False) -> None:
    """
    Background task: run model.offline_part(probe, use_gpu).
    """
    try:
        logger.info("▶️  Starting scan %s (%s)", scan_id, probe)
        active_scans[scan_id]["status"] = "processing"
        result = model.offline_part(probe, use_gpu=use_gpu)
        active_scans[scan_id].update(status="completed", result=result)
        logger.info("✅ Completed scan %s", scan_id)
    except Exception as exc:
        logger.exception("Scan %s failed", scan_id)
        active_scans[scan_id].update(status="failed", error=str(exc))


# This is the single variable ADK looks for:
agent = GarakAgent()
