# agent_with_rag.py
import os
from google.adk.models.lite_llm import LiteLlm
from google.adk.agents import LlmAgent
from .garak_tool import run_pw9_direct
from .rag import get_context

OLLAMA_API = os.getenv("OLLAMA_API_BASE", "http://localhost:11434")
# Initialize ollama/mistral LiteLlm model

ollama_llm = LiteLlm(
    model="ollama_chat/mistral:7b-instruct-q2_K",
    api_base=OLLAMA_API,
    parameters={
        "stream": False,        # ADK handles streaming itself
        "temperature": 0.4,
        "num_ctx": 4096,        # keeps RAM below the 3.5 GiB ceiling
    },
)

# Create the agent with minimal static instruction
agent = LlmAgent(
    model=ollama_llm,
    name="garak_agent",
    description="Garak: command-driven vulnerability scanner for LLMs",
    instruction="You are Garak, a helpful assistant.",
    tools=[run_pw9_direct],
)

def run_agent_with_rag(user_input: str):
    """
    Runs the agent with retrieval augmented generation.
    1. Retrieves relevant instruction chunks based on user input.
    2. Combines retrieved context with user input into a single prompt.
    3. Sends prompt to the ollama/mistral model via agent.model.predict().
    """
    context = get_context(user_input)
    prompt = f"{context}\n\nUser input: {user_input}\nAnswer:"
    response = agent.model.predict(prompt)
    return response

# Example usage:
# response = run_agent_with_rag("scan xss model_type huggingface use GPU")
# print(response)
