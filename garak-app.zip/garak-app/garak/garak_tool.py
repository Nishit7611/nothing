import subprocess
import json
import sys
from pathlib import Path

def run_pw9_direct(
    probes: str,
    model_type: str = "huggingface",
    model_name: str = "gpt2",
    use_gpu: bool = False
) -> str:
    """
    Run pw9.py with specified parameters and capture results.
    - probes: Comma-separated string of probes to use
    - model_type: 'huggingface' or 'ollama'
    - model_name: Model identifier (default: 'gpt2')
    - use_gpu: If True, add --use_gpu flag
    Returns combined stdout from pw9.py and summary_text from latest extracted.*.json if available.
    """
    script_path = Path(__file__).parent / "pw9.py"
    if not script_path.exists():
        return "Scan failed: pw9.py not found."

    # Build the command
    cmd = [
        sys.executable, str(script_path),
        "--probes", probes,
        "--model_type", model_type,
        "--model_name", model_name,
    ]
    if use_gpu:
        cmd.append("--use_gpu")

    # Run pw9.py and capture stdout
    try:
        proc = subprocess.run(
            cmd,
            text=True,
            capture_output=True,
            cwd=script_path.parent,
            check=True
        )
        pw9_stdout = proc.stdout.strip()
    except subprocess.CalledProcessError as e:
        return f"Scan failed: {e.stderr.strip() or e.stdout.strip()}"

    # Find most recent extracted.*.json in the same folder
    json_files = sorted(
        script_path.parent.glob("extracted.*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )

    if json_files:
        try:
            data = json.loads(json_files[0].read_text())
            summary_text = data.get("summary_text", "").strip()
            return pw9_stdout + "\n\n" + summary_text
        except Exception:
            return pw9_stdout

    return pw9_stdout
