#!/usr/bin/env python3

from __future__ import annotations
import os
import re
import json
import time
import subprocess
import warnings
from pathlib import Path
from typing import Any, Dict

# ───────────── constants ─────────────
DATA_DIR = Path("llm")
DATA_DIR.mkdir(exist_ok=True)

PROBES: list[str] = [
    "ansiescape", "atkgen", "av_spam_scanning", "continuation", "encoding",
    "fileformats", "glitch", "goodside", "grandma", "lmrc", "malwaregen",
    "misleading", "packagehallucination", "phrasing", "promptinject",
    "realtoxicityprompts", "snowball", "suffix", "topic", "xss",
]

PRESET_MODELS = ["gpt2", "gpt2-medium", "gpt2-large", "gpt2-xl", "Other…"]

# ───────── helper: is this a text‐generation model? ─────────
_DEFAULT_MODEL_TYPES = {
    "gpt_neox", "llama", "mistral", "bloom", "phi", "qwen", "mixtral", "falcon",
}
MODEL_TYPES_FILE = Path(__file__).with_name("models.txt")

def load_model_types() -> set[str]:
    extra: set[str] = set()
    if MODEL_TYPES_FILE.exists():
        for ln in MODEL_TYPES_FILE.read_text().splitlines():
            ln = ln.strip()
            if ln and not ln.startswith("#"):
                extra.add(ln.lower())
    return {m.lower() for m in _DEFAULT_MODEL_TYPES} | extra

_TEXT_GEN_TAGS = {"text-generation", "text2text-generation", "chat-completion"}
_TEXT_GEN_SUFFIXES = (
    "ForCausalLM", "LMHeadModel", "ForConditionalGeneration", "ForSeq2SeqLM",
)

def is_text_gen_model(folder: str | Path) -> bool:
    cfg_path = Path(folder) / "config.json"
    if not cfg_path.exists():
        return False
    try:
        cfg = json.loads(cfg_path.read_text())
    except Exception:
        return False
    if cfg.get("pipeline_tag") in _TEXT_GEN_TAGS:
        return True
    if any(arch.endswith(_TEXT_GEN_SUFFIXES)
           for arch in cfg.get("architectures", [])):
        return True
    return cfg.get("model_type", "").lower() in load_model_types()

# ───────── helper: run Garak offline (unchanged) ─────────
def run_garak(
    probes: str,
    model_type: str,
    model_name: str,
    use_gpu: bool = False,
    token: str = ""
) -> dict:
    cmd = [
        "python3", "pw9.py",
        "--probes", probes,
        "--model_type", model_type,
        "--model_name", model_name
    ]
    if use_gpu:
        cmd.append("--use_gpu")

    env = os.environ.copy()
    if token:
        env["HF_TOKEN"] = token

    t0 = time.time()
    try:
        res = subprocess.run(cmd, text=True, capture_output=True, check=True, env=env)
    except subprocess.CalledProcessError as e:
        msg = next(
            (ln[6:].strip() for ln in (e.stderr or "").splitlines() if ln.startswith("ERROR:")),
            "Garak execution failed."
        )
        return {"error": msg, "stdout": e.stdout, "stderr": e.stderr}

    execution_time = time.time() - t0

    outs = sorted(
        Path(".").glob("extracted.*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    if not outs:
        return {"error": "No extracted output file found."}

    data = json.loads(outs[0].read_text())
    return {
        "execution_time": execution_time,
        "output_file": outs[0].name,
        "summary": data.get("summary_text", "No summary available"),
        "stdout": res.stdout,
        "detailed_results": data.get("data", [])
    }

# ───────── online Part (unchanged, optional) ─────────
def online_part(probes: str, use_gpu: bool, model_name: str, token: str = "") -> dict:
    model_name = model_name.strip()
    if not model_name:
        return {"error": "Please supply a model name."}
    if re.search(r"[^A-Za-z0-9_\-./]", model_name):
        return {"error": "Invalid characters in model ID."}

    from huggingface_hub import HfApi
    from huggingface_hub.utils import HfHubHTTPError

    api = HfApi()
    if token:
        try:
            api.whoami(token=token)
        except HfHubHTTPError as e:
            return {"error": f"Token rejected: {e}"}

    try:
        meta = api.model_info(model_name, token=token or None)
    except HfHubHTTPError as e:
        return {"error": f"Hugging Face Hub error: {e}"}

    arches = meta.config.get("architectures", [""])
    if not (
        meta.pipeline_tag == "text-generation"
        or (arches and arches[0].endswith("ForCausalLM"))
    ):
        return {"error": "Model is not recognized as a text-generation model."}

    return run_garak(probes, "huggingface", model_name, use_gpu, token)

# ───────── offline Part: always use HuggingFace “gpt2” ─────────
def offline_part(probes: str, use_gpu: bool) -> dict:
    """
    Always run Garak with the default HuggingFace model (gpt2). 
    We’ve removed any Ollama-specific code.
    """
    return run_garak(probes, "huggingface", "gpt2", use_gpu)

# ───────── local safetensors guard (unchanged) ─────────
from .pw9 import verify_local_safetensors
