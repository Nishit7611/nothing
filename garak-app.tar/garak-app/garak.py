# garak.py

from garak.agent import agent
