from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from pathlib import Path
import torch

# Constants for files
BASE_PATH = Path(__file__).parent
DOCS_FILE = BASE_PATH / "instructions_chunks.txt"
EMBEDS_FILE = BASE_PATH / "instructions_embeds.npy"

class Retriever:
    def __init__(self):
        # Load documents
        if not DOCS_FILE.exists() or not EMBEDS_FILE.exists():
            raise FileNotFoundError(
                "Please create 'instructions_chunks.txt' and 'instructions_embeds.npy' first."
            )
        with DOCS_FILE.open("r", encoding="utf-8") as f:
            self.docs = [line.strip() for line in f if line.strip()]
        self.embeddings = np.load(str(EMBEDS_FILE), allow_pickle=True)  # NO trailing comma

        self.embedding_dim = self.embeddings.shape[1]

        # Initialize FAISS index with GPU if available
        if torch.cuda.is_available():
            print("Using GPU for FAISS index.")
            self.res = faiss.StandardGpuResources()  # initialize GPU resources
            index_cpu = faiss.IndexFlatIP(self.embedding_dim)  # CPU index
            self.index = faiss.index_cpu_to_gpu(self.res, 0, index_cpu)  # GPU device 0
        else:
            print("Using CPU for FAISS index.")
            self.index = faiss.IndexFlatIP(self.embedding_dim)

        # Add embeddings to index
        self.index.add(self.embeddings)

        # Load embedder model
        self.embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

    def retrieve(self, query: str, top_k: int = 3) -> list[str]:
        q_emb = self.embedder.encode([query], convert_to_numpy=True)
        D, I = self.index.search(q_emb, top_k)
        return [self.docs[i] for i in I[0] if i < len(self.docs)]

    def get_context(self, query: str) -> str:
        chunks = self.retrieve(query)
        return "\n\n".join(chunks)

# Singleton retriever instance for easy import usage
retriever = Retriever()
def get_context(user_input: str) -> str:
    return retriever.get_context(user_input)
