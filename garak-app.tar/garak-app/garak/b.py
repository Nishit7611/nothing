import faiss
import numpy as np
import concurrent.futures
import time

def create_gpu_index(d, xb):
    res = faiss.StandardGpuResources()
    index_cpu = faiss.IndexFlatIP(d)
    index = faiss.index_cpu_to_gpu(res, 0, index_cpu)
    index.add(xb)
    return index

def create_cpu_index(d, xb):
    index = faiss.IndexFlatIP(d)
    index.add(xb)
    return index

d = 384
xb = np.random.random((1000, d)).astype('float32')

index = None
use_gpu = False

with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
    future = executor.submit(create_gpu_index, d, xb)
    try:
        # Try GPU initialization with 25 seconds timeout
        index = future.result(timeout=25)
        use_gpu = True
        print("Using GPU FAISS index")
    except concurrent.futures.TimeoutError:
        print("GPU FAISS initialization timed out, falling back to CPU")
        index = create_cpu_index(d, xb)
    except Exception as e:
        print(f"GPU FAISS initialization failed: {e}, falling back to CPU")
        index = create_cpu_index(d, xb)

# Use `index` as usual for searching
xq = np.random.random((5, d)).astype('float32')
D, I = index.search(xq, 5)

print("Search results distances:", D)
print("Search results indices:", I)
print(f"Using {'GPU' if use_gpu else 'CPU'} FAISS index")
