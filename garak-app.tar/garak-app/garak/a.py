from sentence_transformers import SentenceTransformer
import numpy as np

embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

with open("instructions_chunks.txt", "r", encoding="utf-8") as f:
    docs = [line.strip() for line in f if line.strip()]

embeddings = embedder.encode(docs, convert_to_numpy=True)
np.save("instructions_embeds.npy", embeddings)
print("Embeddings saved to instructions_embeds.npy")
