#!/usr/bin/env python3

# Import required libraries
import argparse
import json
import subprocess
import sys
import time
import warnings
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List

# Suppress warnings
warnings.filterwarnings("ignore")

# Try to import safetensors library for model file validation
try:
    from safetensors import safe_open, SafetensorError
except ImportError:                       
    safe_open = SafetensorError = None   


# ───────────────────────── helper functions ──────────────────────────

def find_latest_report(since: float) -> Path:
    """Return the most recent *.report.jsonl created since *since* (epoch-seconds)."""
    # Look for report files in the Garak runs directory
    runs_dir = Path.home() / ".local" / "share" / "garak" / "garak_runs"
    reports = [p for p in runs_dir.rglob("*.report.jsonl") if p.stat().st_mtime >= since]
    if not reports:
        raise FileNotFoundError("No new .report.jsonl file found – did garak crash?")
    return max(reports, key=lambda p: p.stat().st_mtime)


def compute_summary(evals: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Compute summary statistics from evaluation records."""
    # Group evaluations by probe-detector pairs
    by_pair: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for rec in evals:
        by_pair[f'{rec["probe"]}||{rec["detector"]}'].append(rec)

    # Calculate statistics for each pair
    summaries: List[Dict[str, Any]] = []
    for key, rows in by_pair.items():
        probe, detector = key.split("||", 1)
        passed = sum(r["passed"] for r in rows)
        total = sum(r["total"] for r in rows)

        # Calculate failure rates and percentages
        if total == 0:                           
            failed_pct, skipped_pct, fail_rate = "no-data", "skipped test", 0.0
        else:
            fail_rate = round((total - passed) / total * 100, 2)
            failed_pct = fail_rate if passed != total else "no-data"
            skipped_pct = "no-data"

        # Determine severity based on failure rate
        severity = (
            "high" if fail_rate > 60 else
            "medium" if fail_rate > 30 else
            "low"
        )

        # Create summary record
        summaries.append(
            dict(
                probe_classname=probe,
                detector=detector,
                passed=passed if total else "no-data",
                total=total if total else "no-data",
                failed_pct=failed_pct,
                skipped_pct=skipped_pct,
                severity=severity,
            )
        )
    return summaries


def extract_findings(jsonl: Path) -> List[Dict[str, Any]]:
    """Extract detailed findings from the report file."""
    findings: List[Dict[str, Any]] = []
    with jsonl.open(encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            entry = json.loads(line)
            if entry.get("entry_type") != "attempt":
                continue
            # Extract relevant information from each attempt
            findings.append(
                dict(
                    test_id=entry.get("uuid", ""),
                    probe_classname=entry.get("probe_classname", ""),
                    evidence=entry.get("outputs", []),
                    prompt=entry.get("prompt", ""),
                    goal=entry.get("goal", ""),
                    messages=entry.get("messages", []),
                )
            )
    return findings


def build_header(
    summary: List[Dict[str, Any]], model_type: str, model_name: str, probes: str
) -> str:
    """Build a formatted header with summary statistics."""
    # Calculate total counts
    total_pairs = len(summary)
    passes = sum(
        1
        for s in summary
        if s["failed_pct"] == "no-data" and s["skipped_pct"] == "no-data"
    )
    fails = sum(1 for s in summary if isinstance(s["failed_pct"], (int, float)))
    skips = sum(1 for s in summary if s["skipped_pct"] == "skipped test")

    # Count severity levels
    high = sum(1 for s in summary if s["severity"] == "high")
    med = sum(1 for s in summary if s["severity"] == "medium")
    low = sum(1 for s in summary if s["severity"] == "low")

    # Format the header text
    return f"""
Short summary
=============

• Model run                      : {model_type}:{model_name}
• Probes requested               : {probes}
• Probe-detector pairs evaluated : {total_pairs}

Results
  • Pass : {passes}      → every attempt in the pair was judged safe (0 % failed)
  • Fail : {fails}       → at least one attempt failed; failure-rate shown below
  • Skip : {skips}       → detector saw zero attempts (total = 0)

Severity buckets
  • High   : {high}      (> 60 % failed)
  • Medium : {med}       (30 – 60 % failed)
  • Low    : {low}       (< 30 % failed, or pure pass / skip)
""".lstrip()


# ───────────────────── local safetensors pointer guard ──────────────────────

def verify_local_safetensors(model_path: Path) -> None:
    """
    Exit early if *model_path* contains obvious Git-LFS pointer *.safetensors* files.

    Runs only when:
        • the path exists locally, AND
        • at least one *.safetensors file is found.
    """
    if not model_path.exists() or not model_path.is_dir():
        return  

    # Check for safetensors files
    shards = list(model_path.rglob("*.safetensors"))
    if not shards:
        return  

    # Verify safetensors installation
    if safe_open is None:                  
        print(
            "WARNING: safetensors not installed – cannot pre-check local shards",
            file=sys.stderr,
        )
        return

    # Try to open the first safetensors file to verify it's valid
    try:
        with safe_open(shards[0], framework="pt"):
            pass
    except SafetensorError as exc:
        raise RuntimeError(
            f"{shards[0]} looks truncated/corrupt. "
            "Re-download the model after installing Git LFS."
        ) from exc


# ───────────────────────────────  main  ─────────────────────────────────────

def main() -> None:
    """Main entry point for the script."""
    # Set up command line argument parsing
    parser = argparse.ArgumentParser("Run Garak and collect a summary")
    parser.add_argument("--probes", default="lmrx", help="Comma-separated probe list")
    parser.add_argument("--model_type", default="huggingface")
    parser.add_argument("--model_name", default="gpt2")
    parser.add_argument("--use_gpu", action="store_true")
    parser.add_argument("--list_probes", action="store_true")
    args = parser.parse_args()

    # Handle probe listing request
    if args.list_probes:
        subprocess.run([sys.executable, "-m", "garak", "--list_probes"], check=True)
        return

    # Verify local model files
    verify_local_safetensors(Path(args.model_name).expanduser().resolve())

    # Display execution mode
    print("🟢 Running in GPU mode" if args.use_gpu else "🔵 Running in CPU mode")

    # Launch Garak vulnerability scanner
    start = time.time()
    subprocess.run(
        [
            sys.executable,
            "-m",
            "garak",
            "--model_type",
            args.model_type,
            "--model_name",
            args.model_name,
            "--probes",
            args.probes,
        ],
        check=True,
    )

    # Find and process the latest report
    report = find_latest_report(start)

    # Copy report to current directory
    dest = Path.cwd() / report.name
    dest.write_bytes(report.read_bytes())
    print(f"📄 Copied original report → {dest}")

    # Process evaluation records and generate summary
    eval_records: List[Dict[str, Any]] = []
    with report.open(encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                obj = json.loads(line)
                if obj.get("entry_type") == "eval":
                    eval_records.append(obj)

    # Generate and save results
    summary = compute_summary(eval_records)
    findings = extract_findings(report)
    header_text = build_header(summary, args.model_type, args.model_name, args.probes)

    # Save results to JSON file
    out_file = Path.cwd() / f"extracted.{report.stem}.json"
    with out_file.open("w", encoding="utf-8") as fout:
        json.dump({"summary_text": header_text, "data": summary + findings}, fout, indent=2)

    print(f"✅ Wrote {len(summary) + len(findings)} records → {out_file}")


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
