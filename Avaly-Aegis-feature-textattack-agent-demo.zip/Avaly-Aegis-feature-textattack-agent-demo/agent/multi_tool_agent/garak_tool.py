"""
garak_tool – Tool functions for the Garak agent
Provides the two FunctionTool callbacks: list_probes() and garak_run().
"""

import subprocess
import json
import sys
from pathlib import Path
from typing import List

# Canonical probe list
PROBE_LIST: List[str] = [
    "ansiescape", "atkgen", "av_spam_scanning", "continuation", "encoding",
    "fileformats", "glitch", "goodside", "grandma", "lmrc", "malwaregen",
    "misleading", "packagehallucination", "phrasing", "promptinject",
    "realtoxicityprompts", "snowball", "suffix", "topic", "xss",
]

def format_probe_list_for_display() -> str:
    """Return JSON array + bullet list for chat display."""
    json_part = json.dumps(PROBE_LIST)
    bullets   = "• " + "\n• ".join(PROBE_LIST)
    return f"{json_part}\n\n{bullets}"

def list_probes() -> str:
    """Return the probe list as JSON + bullets for chat display."""
    return format_probe_list_for_display()

def validate_scan_request(probes: str, model_type: str, model_name: str) -> None:
    """Raise ValueError if probes or model parameters are invalid."""
    unknown = [p for p in probes.split(",") if p.strip() not in PROBE_LIST]
    if unknown:
        raise ValueError(f"Unknown probes: {', '.join(unknown)}")
    if model_type.lower() not in {"huggingface", "ollama"}:
        raise ValueError("model_type must be 'huggingface' or 'ollama'")
    if not model_name:
        raise ValueError("model_name may not be blank")

def run_garakwrapper_direct(
    probes: str,
    model_type: str = "huggingface",
    model_name: str = "gpt2",
    use_gpu: bool = False
) -> str:
    """
    Directly invoke GarakWrapper.py via subprocess, capture stdout, then append
    the latest summary_text from extracted.*.json.
    """
    validate_scan_request(probes, model_type, model_name)
    script_path = Path(__file__).parent / "GarakWrapper.py"
    if not script_path.exists():
        return "Scan failed: GarakWrapper.py not found."

    cmd = [sys.executable, str(script_path),
           "--probes", probes,
           "--model_type", model_type,
           "--model_name", model_name]
    if use_gpu:
        cmd.append("--use_gpu")

    try:
        proc = subprocess.run(cmd,
                              text=True,
                              capture_output=True,
                              cwd=script_path.parent,
                              check=True)
        wrapper_stdout = proc.stdout.strip()
    except subprocess.CalledProcessError as e:
        return f"Scan failed: {e.stderr.strip() or e.stdout.strip()}"

    json_files = sorted(
        script_path.parent.glob("extracted.*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    if json_files:
        try:
            data = json.loads(json_files[0].read_text())
            summary_text = data.get("summary_text", "").strip()
            return wrapper_stdout + "\n\n" + summary_text
        except Exception:
            return wrapper_stdout
    return wrapper_stdout
