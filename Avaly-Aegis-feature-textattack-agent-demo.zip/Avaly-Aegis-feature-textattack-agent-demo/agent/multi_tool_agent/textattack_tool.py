from .app.textattack_wrapper import Finding
from pydantic import BaseModel
import pandas as pd


class TAParams(BaseModel):
    model_name: str
    dataset_name: str
    recipe_name: str
    n: int


ALLOWED_RECIPES = [
   "ansiescape", "atkgen", "av_spam_scanning", "continuation", "encoding",
    "fileformats", "glitch", "goodside", "grandma", "lmrc", "malwaregen",
    "misleading", "packagehallucination", "phrasing", "promptinject",
    "realtoxicityprompts", "snowball", "suffix", "topic", "xss",
]


def run_textattack(
    model_name: str,
    dataset_name: str,
    recipe_name: str,
    n: int,
) -> dict:
    """
    Runs a TextAttack adversarial attack.
    Required arguments:
        model_name: str,
        dataset_name: str,
        recipe_name: str,
        n: int,
    """
    if recipe_name not in ALLOWED_RECIPES:
        return {
            "error": f"Recipe {recipe_name} is not allowed. Please use one of the following: {ALLOWED_RECIPES}"
        }

    runner = Finding(
        model_from_hf=model_name,
        dataset_from_hf=dataset_name,
        recipe=recipe_name,
        n=n,
        model_from_local=None,
        dataset_from_local=None,
    )
    result = runner.run()
    print("\n\nresult from textattack ->>>>\n\n", result)
    print("type of result ->>>>\n\n", type(result))
    return result

def recipes() -> dict:
    """
    Returns a JSON-serializable dict with a 'probes' key listing
    all allowed Garak probes. No arguments required.

     WHEN TO CALL THIS TOOL:
      - If the user asks “What probes are available?”
      - If the user asks “Which Garak probes can I use?”
      - If the user asks a question similar to the above
      - If the user tries to run an Garak without specifying a probe_name.

    The LLM should not answer probe-related queries itself but must always call this function

    Example return: {"probes": ["textfooler", "bae", ...]}
    """
    return {"probes": ALLOWED_RECIPES}
