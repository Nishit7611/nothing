// src/components/Graphs.jsx
import React from 'react';
import { ResponsiveBar } from '@nivo/bar';
import { ResponsiveLine } from '@nivo/line';
import { darkTheme } from '../nivoTheme';

export default function Graphs({ reports }) {
    const summaryData = reports.map((rep, idx) => {
        const summary = rep['Attack Summary'];
        return {
            report: `R${idx + 1}`,
            successful: summary['Number of successful attacks:'],
            failed: summary['Number of failed attacks:'],
            skipped: summary['Number of skipped attacks:'],
        };
    });

    const asrData = reports.map((rep, idx) => {
        const asrString = rep['Attack Summary']['Attack Success Rate (ASR) Percentage'];
        const asrValue = parseFloat(asrString.replace('%', '')) || 0;
        return { report: `R${idx + 1}`, asr: asrValue };
    });
    const asrSeries = {
        id: 'ASR (%)',
        color: '#f39c12',
        data: asrData.map((d) => ({ x: d.report, y: d.asr })),
    };

    return (
        <div className="graphs-root">
            {/* ────────────────────────────────────────────
         1) Attack Outcomes (Stacked Bar Chart)
      ────────────────────────────────────────────── */}
            <div className="graphs-bar-chart-container">
                <h3 className="graphs-bar-chart-title">
                    Attack Outcomes
                </h3>
                <div className="graphs-bar-chart-inner" >
                    <ResponsiveBar
                        data={summaryData}
                        keys={['successful', 'failed', 'skipped']}
                        indexBy="report"
                        margin={{ top: 40, right: 20, bottom: 60, left: 60 }}
                        padding={0.3}
                        layout="vertical"
                        theme={darkTheme}
                        colors={(bar) => {
                            if (bar.id === 'successful') return '#6a0dad';
                            if (bar.id === 'failed') return '#e74c3c';
                            return '#888888';
                        }}
                        borderRadius={3}
                        borderColor={{ from: 'color', modifiers: [['darker', 1.2]] }}
                        axisTop={null}
                        axisRight={null}
                        axisBottom={{
                            tickSize: 0,
                            tickPadding: 8,
                            tickRotation: -45,
                            legend: 'Report',
                            legendPosition: 'middle',
                            legendOffset: 50,
                            tickTextColor: '#ddd',
                        }}
                        axisLeft={{
                            tickSize: 0,
                            tickPadding: 8,
                            tickRotation: 0,
                            legend: 'Count',
                            legendPosition: 'middle',
                            legendOffset: -50,
                            tickTextColor: '#ddd',
                        }}
                        labelSkipWidth={12}
                        labelSkipHeight={12}
                        labelTextColor="#fff"
                        tooltip={({ id, value, indexValue }) => (
                            <div className="graphs-bar-chart-tooltip">
                                <strong>{id.toUpperCase()}</strong> in{' '}
                                <strong>{indexValue}</strong>: {value}
                            </div>
                        )}
                        animate={true}
                        motionConfig="slow"
                        role="img"
                        ariaLabel="Grouped bar chart showing successful, failed, and skipped attacks per report"
                        barAriaLabel={(e) =>
                            `${e.id} in ${e.indexValue}: ${e.formattedValue}`
                        }
                    />
                </div>
            </div>

            {/* ────────────────────────────────────────────
         2) ASR (%) (Single‐Series Line Chart)
      ────────────────────────────────────────────── */}
            <div className="graphs-line-chart-container">
                <h3 className="graphs-line-chart-title">
                    ASR (%) by Report
                </h3>
                <div className="graphs-line-chart-inner">
                    <ResponsiveLine
                        data={[asrSeries]}
                        margin={{ top: 40, right: 80, bottom: 60, left: 60 }}
                        xScale={{ type: 'point' }}
                        yScale={{ type: 'linear', min: 0, max: 100, stacked: false }}
                        theme={darkTheme}
                        colors={{ datum: 'color' }}
                        curve="monotoneX"
                        lineWidth={4}
                        pointSize={8}
                        pointColor={{ from: 'color' }}
                        pointBorderWidth={2}
                        pointBorderColor={{ from: 'serieColor' }}
                        enableArea={true}
                        areaOpacity={0.15}
                        enableCrosshair={true}
                        crosshairType="cross"
                        useMesh={true}
                        axisTop={null}
                        axisRight={{
                            orient: 'right',
                            tickSize: 0,
                            tickPadding: 8,
                            tickRotation: 0,
                            legend: 'ASR (%)',
                            legendOffset: 40,
                            legendPosition: 'middle',
                            tickTextColor: '#ddd',
                        }}
                        axisBottom={{
                            orient: 'bottom',
                            tickSize: 0,
                            tickPadding: 8,
                            tickRotation: -45,
                            legend: 'Report',
                            legendOffset: 50,
                            legendPosition: 'middle',
                            tickTextColor: '#ddd',
                        }}
                        axisLeft={{
                            orient: 'left',
                            tickSize: 0,
                            tickPadding: 8,
                            tickRotation: 0,
                            legend: 'ASR (%)',
                            legendOffset: -50,
                            legendPosition: 'middle',
                            tickTextColor: '#ddd',
                        }}
                        tooltip={({ point }) => (
                            <div className="graphs-line-chart-tooltip">
                                <strong>Report:</strong> {point.data.xFormatted} <br />
                                <strong>ASR:</strong> {point.data.yFormatted}%
                            </div>
                        )}
                        enablePoints={true}
                        pointLabel={(d) => `${d.y.toFixed(1)}%`}
                        pointLabelYOffset={-12}
                        legends={[
                            {
                                anchor: 'top-right',
                                direction: 'row',
                                translateX: 20,
                                translateY: -20,
                                itemsSpacing: 10,
                                itemDirection: 'left-to-right',
                                itemWidth: 100,
                                itemHeight: 20,
                                itemOpacity: 0.75,
                                symbolSize: 12,
                                symbolShape: 'circle',
                                itemTextColor: '#ddd',
                                effects: [
                                    {
                                        on: 'hover',
                                        style: {
                                            itemBackground: '#333',
                                            itemOpacity: 1,
                                        },
                                    },
                                ],
                            },
                        ]}
                        animate={true}
                        motionConfig="molasses"
                        role="img"
                        ariaLabel="Line chart showing Attack Success Rate percentage for each report"
                    />
                </div>
            </div>
        </div>
    );
}
