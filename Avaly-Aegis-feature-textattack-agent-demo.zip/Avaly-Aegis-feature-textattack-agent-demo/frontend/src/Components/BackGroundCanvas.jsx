// src/components/BackgroundCanvas.jsx
import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';

export default function BackgroundCanvas() {
    const mountRef = useRef(null);

    useEffect(() => {
        // 1. Scene, Camera, Renderer
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x121212); // very dark background

        const camera = new THREE.PerspectiveCamera(
            50,
            window.innerWidth / window.innerHeight,
            0.1,
            1000
        );
        camera.position.z = 25;

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(window.devicePixelRatio);
        renderer.domElement.style.position = 'fixed';
        renderer.domElement.style.top = '0';
        renderer.domElement.style.left = '0';
        renderer.domElement.style.zIndex = '-1';
        mountRef.current.appendChild(renderer.domElement);

        // 2. Create a cloud of points
        const pointCount = 500;
        const positions = new Float32Array(pointCount * 3);
        for (let i = 0; i < pointCount * 3; i++) {
            positions[i] = (Math.random() - 0.5) * 40;
        }

        const pointsGeometry = new THREE.BufferGeometry();
        pointsGeometry.setAttribute(
            'position',
            new THREE.BufferAttribute(positions, 3)
        );

        // Create a circular sprite texture for point material
        const circleCanvas = document.createElement('canvas');
        circleCanvas.width = 64;
        circleCanvas.height = 64;
        const ctx = circleCanvas.getContext('2d');
        ctx.beginPath();
        ctx.arc(32, 32, 30, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        const circleTexture = new THREE.CanvasTexture(circleCanvas);

        const pointsMaterial = new THREE.PointsMaterial({
            color: 0x6a0dad,    // dark purple
            size: 0.2,
            sizeAttenuation: true,
            map: circleTexture,
            transparent: true,
            opacity: 0.75,
            alphaTest: 0.01
        });

        const pointCloud = new THREE.Points(pointsGeometry, pointsMaterial);
        scene.add(pointCloud);

        // 3. Connect nearby points with lines (cyber-network look)
        const threshold = 3; // max distance to draw a line
        const lineMaterial = new THREE.LineBasicMaterial({
            color: 0x6a0dad,    // same dark purple
            transparent: true,
            opacity: 0.2,
            linewidth: 1
        });

        // Precompute an array of point positions for distance checks
        const posArray = pointsGeometry.attributes.position.array;

        // Build a single BufferGeometry containing all line segments
        const maxConnections = pointCount * 4; // approximate upper bound
        const linePositions = new Float32Array(maxConnections * 2 * 3);
        let linePosIndex = 0;

        for (let i = 0; i < pointCount; i++) {
            const ix = i * 3;
            const x1 = posArray[ix];
            const y1 = posArray[ix + 1];
            const z1 = posArray[ix + 2];
            for (let j = i + 1; j < pointCount; j++) {
                const jx = j * 3;
                const x2 = posArray[jx];
                const y2 = posArray[jx + 1];
                const z2 = posArray[jx + 2];

                const dx = x1 - x2;
                const dy = y1 - y2;
                const dz = z1 - z2;
                const distSq = dx * dx + dy * dy + dz * dz;
                if (distSq < threshold * threshold) {
                    // add segment (x1,y1,z1)→(x2,y2,z2)
                    linePositions[linePosIndex++] = x1;
                    linePositions[linePosIndex++] = y1;
                    linePositions[linePosIndex++] = z1;
                    linePositions[linePosIndex++] = x2;
                    linePositions[linePosIndex++] = y2;
                    linePositions[linePosIndex++] = z2;
                }
            }
        }

        // Create BufferGeometry for the lines
        const linesGeometry = new THREE.BufferGeometry();
        linesGeometry.setAttribute(
            'position',
            new THREE.BufferAttribute(linePositions.slice(0, linePosIndex), 3)
        );
        const lineSegments = new THREE.LineSegments(linesGeometry, lineMaterial);
        scene.add(lineSegments);

        // 4. Animation loop
        const clock = new THREE.Clock();
        function animate() {
            const elapsed = clock.getElapsedTime();

            // Rotate the entire point cloud slowly
            pointCloud.rotation.y = elapsed * 0.01;
            pointCloud.rotation.x = elapsed * 0.005;

            // Rotate the lines (same as points so they stay aligned)
            lineSegments.rotation.y = elapsed * 0.01;
            lineSegments.rotation.x = elapsed * 0.005;

            renderer.render(scene, camera);
            requestAnimationFrame(animate);
        }
        animate();

        // 5. Handle window resize
        function onResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }
        window.addEventListener('resize', onResize);

        // 6. Cleanup on unmount
        return () => {
            window.removeEventListener('resize', onResize);
            mountRef.current.removeChild(renderer.domElement);

            pointsGeometry.dispose();
            pointsMaterial.dispose();
            linesGeometry.dispose();
            lineMaterial.dispose();
            renderer.dispose();
        };
    }, []);

    return <div ref={mountRef} />;
}
