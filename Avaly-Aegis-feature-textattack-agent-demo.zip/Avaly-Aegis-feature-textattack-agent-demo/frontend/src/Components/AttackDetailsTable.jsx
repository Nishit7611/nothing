import React, { useMemo, useState } from 'react';
import {
    useReactTable,
    getCoreRowModel,
    getSortedRowModel,
    flexRender,
} from '@tanstack/react-table';

/**
 * @param {Array<Object>} data
 *   each object has keys:
 *     original_text, perturbed_text, original_score,
 *     perturbed_score, original_output, perturbed_output,
 *     ground_truth_output, num_queries, result_type
 */
export default function AttackDetailsTable({ data }) {
    const [sorting, setSorting] = useState([]);

    // 1) Define columns
    const columns = useMemo(
        () => [
            {
                id: 'expand',
                header: () => null,
                cell: ({ row, table }) => (
                    <span
                        className="attack-details-expand-arrow"
                        onClick={() => row.toggleExpanded()}
                    >
                        {row.getIsExpanded() ? '▼' : '▶'}
                    </span>
                ),
            },
            {
                accessorKey: 'original_text',
                header: 'Original Text',
                cell: (info) => (
                    <div className="attack-details-original-text">
                        {info.getValue()}
                    </div>
                ),
                size: 300,
            },
            {
                accessorKey: 'perturbed_text',
                header: 'Perturbed Text',
                cell: (info) => (
                    <div className="attack-details-perturbed-text">
                        {info.getValue()}
                    </div>
                ),
                size: 300,
            },
            {
                accessorKey: 'original_score',
                header: () => (
                    <span className="attack-details-header-flex">
                        Original Score
                    </span>
                ),
                cell: (info) => info.getValue().toFixed(4),
                size: 80,
                enableSorting: true,
            },
            {
                accessorKey: 'perturbed_score',
                header: () => <span className="attack-details-header-flex">Perturbed Score</span>,
                cell: (info) => info.getValue().toFixed(4),
                size: 80,
                enableSorting: true,
            },
            {
                accessorKey: 'num_queries',
                header: 'Queries',
                cell: (info) => info.getValue(),
                size: 60,
                enableSorting: true,
            },
            {
                accessorKey: 'result_type',
                header: 'Result',
                cell: (info) => info.getValue(),
                size: 100,
            },
        ],
        []
    );

    // 2) Create the table instance
    const table = useReactTable({
        data,
        columns,
        state: { sorting },
        onSortingChange: setSorting,
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        debugTable: false,
    });

    return (
        <div className="attack-details-table-outer">
            <table className="attack-details-table">
                <thead>
                    {table.getHeaderGroups().map((headerGroup) => (
                        <tr key={headerGroup.id}>
                            {headerGroup.headers.map((header) => (
                                <th
                                    key={header.id}
                                    colSpan={header.colSpan}
                                    className="attack-details-table-header"
                                    onClick={header.column.getToggleSortingHandler()}
                                >
                                    <div className="attack-details-header-flex">
                                        {flexRender(
                                            header.column.columnDef.header,
                                            header.getContext()
                                        )}
                                        {{
                                            asc: <span className="attack-details-sort-arrow">🔼</span>,
                                            desc: <span className="attack-details-sort-arrow">🔽</span>,
                                        }[header.column.getIsSorted()] ?? null}
                                    </div>
                                </th>
                            ))}
                        </tr>
                    ))}
                </thead>

                <tbody>
                    {table.getRowModel().rows.map((row, rowIndex) => (
                        <React.Fragment key={row.id}>
                            <tr
                                className={`attack-details-table-row${rowIndex % 2 === 0 ? ' even' : ' odd'}`}
                            >
                                {row.getVisibleCells().map((cell) => (
                                    <td
                                        key={cell.id}
                                        className="attack-details-table-cell"
                                    >
                                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                    </td>
                                ))}
                            </tr>

                            {row.getIsExpanded() && (
                                <tr>
                                    <td colSpan={row.getVisibleCells().length} className="attack-details-table-expanded-cell">
                                        <div className="attack-details-table-expanded-content">
                                            {/* Example of expanded content below each row */}
                                            <div className="attack-details-table-expanded-text">
                                                <strong>Ground-truth Output:</strong>{' '}
                                                {row.original.ground_truth_output} &nbsp; | &nbsp;
                                                <strong>Original Output:</strong> {row.original.original_output}{' '}
                                                &nbsp; | &nbsp;
                                                <strong>Perturbed Output:</strong> {row.original.perturbed_output}
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            )}
                        </React.Fragment>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
