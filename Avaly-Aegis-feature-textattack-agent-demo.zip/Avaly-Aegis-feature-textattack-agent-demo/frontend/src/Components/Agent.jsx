// src/components/Agent.jsx
import React, { useState, useEffect } from 'react';
import { run } from '../api';

export default function Agent({ sessionId, messages, setMessages }) {
    const [inputText, setInputText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    }, [messages])

    const handleSend = async () => {
        if (!inputText.trim()) return;
        if (!sessionId) {
            setError('No session ID; please create a session first.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setInputText('');

        // Append the user's message to the chat view immediately
        setMessages((prev) => [...prev, { role: 'user', text: inputText }]);

        try {
            const payload = {
                appName: 'multi_tool_agent',
                userId: 'clyde',
                sessionId: sessionId,
                newMessage: {
                    parts: [{ text: inputText }],
                    role: 'user',
                },
                streaming: false,
            };

            const events = await run(payload); // Array of Event objects
            console.log("\n\nevents\n\n", events)
            if (events.report_file) {
                setMessages(prev => [
                  ...prev,
                  { role: "agent", text: events.report_file }
                ]);
                return;
              }
            // Find the first event that actually has `text`
            let replyText = '';
            for (const evt of events) {
                const part = evt.content?.parts?.[0];
                if (part && typeof part.text === 'string') {
                    replyText = part.text.trim();
                    break;
                }
            }

            if (replyText) {
                setMessages((prev) => [...prev, { role: 'agent', text: replyText }]);
            } else {
                throw new Error('No reply text found in ADK response');
            }
        } catch (err) {
            console.error(err);
            setError(err.message || 'Failed to send prompt');
        } finally {
            setIsLoading(false);
            setInputText('');
        }

    };

    return (
        <div className="agent-root">
            {/* Chat window */}
            <div className="agent-chat-window">
                {messages.length === 0 && (
                    <p className="agent-chat-empty">No messages yet. Type something below and hit Send.</p>
                )}
                {messages.map((msg, idx) => {
                    const isReportLink =
                        msg.role === 'agent' &&
                        typeof msg.text === 'string' &&
                        msg.text.startsWith('/attack_data/') &&
                        msg.text.endsWith('_attack_summary.json');
                    const content = isReportLink ? (
                        // make it a link that opens in a new tab
                        <>
                            The Attack Report is ready. Click here to view it:{'   '}
                            <span className="agent-report-link-span">
                                <a
                                    href={msg.text}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="agent-report-link"
                                >
                                    View Attack Report
                                </a>
                            </span>
                        </>
                    ) : (
                        msg.text
                    );
                    return (
                        <div
                            key={idx}
                            className={`agent-chat-message${msg.role === 'user' ? ' user' : ' agent'}`}
                        >
                            <div className="agent-chat-bubble">
                                <span className={`agent-chat-bubble-label${msg.role === 'user' ? ' user' : ' agent'}`}>{msg.role === 'user' ? 'You:' : 'Agent:'} </span>
                                {content}
                            </div>
                        </div>
                    );
                })}
            </div>
            {/* Input area */}
            <div className="agent-input-row">
                <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            if (!isLoading) handleSend();
                        }
                    }}
                    placeholder="Type your message..."
                    className="agent-input-box"
                    disabled={isLoading}
                />
                <button
                    onClick={handleSend}
                    disabled={isLoading}
                    className="agent-send-button"
                >
                    {isLoading ? (
                        <span className="loadingText">Agent is thinking</span>
                    ) : (
                        "Send"
                    )}
                </button>
            </div>
            {error && (
                <div className="agent-error">Error: {error}</div>
            )}
        </div>
    );
}
