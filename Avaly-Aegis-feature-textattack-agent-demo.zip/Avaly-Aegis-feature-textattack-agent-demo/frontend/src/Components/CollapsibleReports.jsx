import React, { useState } from 'react';
import AttackDetailsTable from './AttackDetailsTable';

export default function CollapsibleReports({ reports }) {
    // Track which report indices are expanded
    const [expandedIndex, setExpandedIndex] = useState(null);

    const toggleExpand = (idx) => {
        setExpandedIndex(prev => (prev === idx ? null : idx));
    };

    return (
        <div className="collapsible-reports-root">
            {reports.map((report, idx) => {
                const summary = report['Attack Summary'];
                const details = report.attack_details;
                return (
                    <div
                        key={idx}
                        className="collapsible-reports-container"
                    >
                        {/* Summary Header */}
                        <div
                            onClick={() => toggleExpand(idx)}
                            className="collapsible-reports-summary-header"
                        >
                            <div>
                                <strong>Report #{idx + 1}:</strong>{' '}
                                {summary['Attack Success Rate (ASR) Percentage']} ASR, Severity{' '}
                                {summary.Severity},{' '}Model: {summary['Model']}
                            </div>
                            <div className="collapsible-reports-summary-arrow">
                                {expandedIndex === idx ? '▾' : '▸'}
                            </div>
                        </div>
                        {/* Expanded Content */}
                        {expandedIndex === idx && (
                            <div className="collapsible-reports-summary-content">
                                {/* Full Attack Summary Fields */}
                                <div className="collapsible-reports-summary-fields">
                                    <h4 className="collapsible-reports-summary-title">Attack Summary</h4>
                                    <ul className="collapsible-reports-summary-list">
                                        {Object.entries(summary).map(([key, value]) => (
                                            <li
                                                key={key}
                                                className="collapsible-reports-summary-list-item"
                                            >
                                                <span className="collapsible-reports-summary-key">{key}:</span>
                                                <span>{value}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                {/* Attack Details Table */}
                                <div>
                                    <h4 className="collapsible-reports-details-title">Attack Details</h4>
                                    <AttackDetailsTable data={details} />
                                </div>
                            </div>
                        )}
                    </div>
                );
            })}
        </div>
    );
}
