import React from 'react';
import logo from './avaly_logo.png';
import { useNavigate } from 'react-router-dom';

export default function Header() {
    const navigate = useNavigate();
    return (
        <header className="app-header">
            <div className="header-logo" onClick={() => navigate('/')}>
                <img src={logo} alt="Agentic AI Logo" />
            </div>
        </header>
    );
}

