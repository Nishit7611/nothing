import React, { useState } from 'react';
import { createSession, getReports } from '../api';
import CollapsibleReports from '../Components/CollapsibleReports';
import Graphs from '../Components/Graphs';
import Agent from '../Components/Agent';

function Dashboard() {
    const [sessionId, setSessionId] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [activeTab, setActiveTab] = useState('Agent'); // 'Agent' or 'Reports'
    const [reports, setReports] = useState([]);
    const [messages, setMessages] = useState([]);
    
    const handleTabChange = (tab) => {
        setActiveTab(tab);
        if (tab === 'Reports') {
            //TODO: Loading indicator
            handleGetReports();
        }
    };

    const handleCreateSession = () => {
        setIsLoading(true);
        setError(null);
        createSession()
            .then((data) => {
                if (!data.id) {
                    throw new Error('No sessionId in response');
                }
                setSessionId(data.id);
            })
            .catch((err) => {
                console.error(err);
                setError(err.message || 'Failed to create session');
            })
            .finally(() => {
                setIsLoading(false);
            });
    };

    const handleGetReports = () => {
        getReports()
            .then((data) => {
                console.log(data);
                setReports(data);
            });
    };

    return (
        <div className="dashboard-container">
            {/* Session Button */}
            <div className="session-row">
                <button
                    className="button"
                    onClick={handleCreateSession}
                    disabled={isLoading}
                >
                    {isLoading ? 'Creating Session...' : 'Start Agent Session'}
                </button>
                {error && (
                    <div className="session-error">
                        Error: {error}
                    </div>
                )}
                {sessionId && (
                    <div className="session-id">
                        Session ID: {sessionId}
                    </div>
                )}
            </div>

            {/* Tabs */}
            <div className="tab-header">
                {['Agent', 'Reports'].map((tab) => (
                    <div
                        key={tab}
                        className={`tab ${activeTab === tab ? 'active' : ''}`}
                        onClick={() => handleTabChange(tab)}
                    >
                        {tab}
                    </div>
                ))}
            </div>

            {/* Content Area */}
            <div className="tab-content">
                {activeTab === 'Agent' && (
                    <div className="dashboard-agent-tab-content">
                        <Agent
                            sessionId={sessionId}
                            messages={messages}
                            setMessages={setMessages}
                        />
                    </div>
                )}
                {activeTab === 'Reports' && reports && reports.length > 0 && (
                    <div>
                        <Graphs reports={reports} />
                        <CollapsibleReports reports={reports} />
                    </div>
                )}
                {activeTab === 'Reports' && reports && reports.length === 0 && (
                    <div>
                        <p>No reports found</p>
                    </div>
                )}
            </div>
        </div>
    );
}

export default Dashboard;
