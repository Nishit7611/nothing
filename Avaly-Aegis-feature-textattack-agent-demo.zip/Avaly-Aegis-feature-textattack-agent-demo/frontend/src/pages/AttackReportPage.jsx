// src/AttackReportPage.jsx
import React, { useEffect, useState } from 'react';
import { useParams, Link }           from 'react-router-dom';
import AttackDetailsTable            from '../Components/AttackDetailsTable';
import { getAttackData } from '../api';

export default function AttackReportPage() {
  const { filename } = useParams();                       
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    getAttackData(`/attack_data/${filename}`)
      .then((res) => {
        console.log("\n\nres\n\n", res)
        if (!res["Attack Summary"]) throw new Error(`Could not load ${filename}`);
        setData(res);
      })             // adjust if your JSON shape is different
      .catch((err) => setError(err.message));
  }, [filename]);

  if (error) return <div className="attack-report-error">{error}</div>;
  if (!data)  return <div className="attack-report-loading">Loading report…</div>;
  const summary = data['Attack Summary'];
  const details = data.attack_details;

  return (
    <div className="attack-report-root">
      <div className="attack-report-container">
        {/* Summary Header */}
        <div className="attack-report-summary-header">
          <div>
            <strong>Report :</strong>{' '}
            {summary['Attack Success Rate (ASR) Percentage']} ASR, Severity{' '}
            {summary.Severity},{' '}Model: {summary['Model']}
          </div>
          <div className="attack-report-summary-arrow">
            {'▾'}
          </div>
        </div>
        {/* Expanded Content */}
        <div className="attack-report-summary-content">
          {/* Full Attack Summary Fields */}
          <div className="attack-report-summary-fields">
            <h4 className="attack-report-summary-title">Attack Summary</h4>
            <ul className="attack-report-summary-list">
              {Object.entries(summary).map(([key, value]) => (
                <li key={key} className="attack-report-summary-list-item">
                  <span className="attack-report-summary-key">{key}:</span>
                  <span>{value}</span>
                </li>
              ))}
            </ul>
          </div>
          {/* Attack Details Table */}
          <div>
            <h4 className="attack-report-details-title">Attack Details</h4>
            <AttackDetailsTable data={details} />
          </div>
        </div>
      </div>
    </div>
  );
}
