import React from 'react';
import { useNavigate } from 'react-router-dom';
import ScanTool from '../Components/scan_tool.png'

function Home() {
    const navigate = useNavigate();

    const handleClick = () => {
        navigate('/dashboard');
    };

    return (
        <div className="home-container">
            <div className="home-intro">
                <div className="banner">
                    <h1>Aegis Striker</h1>
                    <h3>Advanced AI Security Testing Platform</h3>
                    <button className="button" onClick={handleClick}>
                        Get Started
                    </button>
                </div>
                <div className="two-column-grid">
                    <p className="home-intro-text">

                        Aegis Striker redefines the landscape of adversarial testing by introducing the first fully agentic, text-based platform designed to challenge and fortify natural language models.
                    </p>
                    <p> <img src={ScanTool} alt="Scan Tool" /></p>
                    <p className="home-intro-text">
                        Aegis Striker empowers teams to proactively uncover weaknesses, improve model robustness, and stay ahead of adversarial actors in an ever-evolving threat environment.

                    </p>
                </div>

            </div>
        </div>
    );
}

export default Home;
