import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import BackGroundCanvas from './Components/BackGroundCanvas';
import Header from './Components/Header';
import AttackReportPage from './pages/AttackReportPage';

function App() {
    return (
        <div className="app-root-container">
            <BackGroundCanvas />
            <Header />
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/attack_data/:filename" element={<AttackReportPage />} />
            </Routes>
        </div>
    );
}

export default App;
