// src/nivoTheme.js
export const darkTheme = {
    background: '#121212',
    textColor: '#e0e0e0',
    fontSize: 12,
    axis: {
        domain: {
            line: { stroke: '#444', strokeWidth: 1 },
        },
        ticks: {
            line: { stroke: '#444', strokeWidth: 1 },
            text: { fill: '#aaa' },
        },
        legend: {
            text: { fill: '#ddd' },
        },
    },
    grid: {
        line: { stroke: '#333', strokeWidth: 1 },
    },
    legends: {
        text: { fill: '#ddd' },
    },
    tooltip: {
        container: {
            background: '#222',
            color: '#fff',
            fontSize: '13px',
            borderRadius: '4px',
            boxShadow: '0 2px 10px rgba(0,0,0,0.7)',
            minWidth: '150px',
            padding: '8px 12px',
        },
    },
};
