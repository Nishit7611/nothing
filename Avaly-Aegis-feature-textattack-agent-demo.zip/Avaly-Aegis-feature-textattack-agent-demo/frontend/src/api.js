// A simple wrapper for REST calls. Adjust the base URL as needed.
const BASE_URL = 'http://localhost:5000/api';

export async function fetchStatus() {
    const response = await fetch(`${BASE_URL}/status`);
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json(); // expects { message: "..." }
}

export async function createSession() {
    const response = await fetch(`${BASE_URL}/create_session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },

    });
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
}

export async function getReports() {
    const response = await fetch(`${BASE_URL}/get_reports`);
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
}

export async function run(payload) {
    const response = await fetch(`${BASE_URL}/run`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
    });

    if (!response.ok) {
        const errText = await response.text();
        throw new Error(`ADK error: ${response.status} ${errText}`);
    }

    const data = await response.json();
    return data;
}

export async function getAttackData(filename) {
    const response = await fetch(`${BASE_URL}${filename}`);
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
}
