import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
    plugins: [react()],
    server: {
        port: 3000
    },
    alias: {
        // remap the old CJS path → new ESM path for stats
        'three/examples/js/libs/stats.min':
            'three/examples/jsm/libs/stats.module'
    }
});
