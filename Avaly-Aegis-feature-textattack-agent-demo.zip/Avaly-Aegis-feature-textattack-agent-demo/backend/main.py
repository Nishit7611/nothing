# save as backend/main.py

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import httpx
import os
import json
import re


app = FastAPI()

ADK_API_URL = "http://agent:8000"

# Allow CORS from React dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/status")
async def get_status():
    return {"message": "OK"}


@app.post("/api/create_session")
async def create_session():
    # Use AsyncClient so we don't block the event loop
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            resp = await client.post(
                f"{ADK_API_URL}/apps/multi_tool_agent/users/clyde/sessions",
            )
        except httpx.RequestError as exc:
            # If ADK server is down or unreachable, return a 502 so that React sees CORS headers
            raise HTTPException(status_code=502, detail=f"ADK request failed: {exc}")

    # Forward ADK’s JSON response
    return resp.json()


@app.get("/api/get_reports")
async def get_reports():
    reports = []
    for file in os.listdir("/attack_data"):
        print(file)
        if file.endswith(".json") and "REPORT" in file:
            with open(os.path.join("/attack_data", file), "r") as f:
                data = json.load(f)
                reports.append(data)
    return reports


@app.post("/api/run")
async def run(payload: dict):
    adk_url = f"{ADK_API_URL}/run"

    async with httpx.AsyncClient(timeout=1000.0) as client:
        try:
            # Forward exactly what we received to ADK’s /run
            print("\n\npayload\n\n", payload)
            resp = await client.post(f"{ADK_API_URL}/run", json=payload)
        except httpx.RequestError as exc:
            raise HTTPException(
                status_code=502, detail=f"Failed to reach ADK at {adk_url}: {exc}"
            )

    # If ADK returned a non‐200, bubble that back:
    if resp.status_code != 200:
        raise HTTPException(
            status_code=resp.status_code,
            detail=f"ADK returned {resp.status_code}: {resp.text}",
        )

    # Otherwise return ADK’s JSON directly
    json_resp = resp.json()

     # 1) if the JSON has an explicit report_file key, return it
    if isinstance(json_resp, dict) and json_resp.get("report_file"):
        return json_resp

    # 2) otherwise fall back to regex on the raw body
    text = resp.text
    match = re.search(
        r'(/attack_data/REPORT_[\d\-T:]+_attack_summary\.json)',
        text
    )
    if match:
        return {"report_file": match.group(1)}

    # 3) give up and return whatever JSON we got (or None)
    return json_resp

@app.get("/api/attack_data/{filename}")
async def get_attack_data(filename: str):
    if os.path.exists(os.path.join("/attack_data", filename)):
        with open(os.path.join("/attack_data", filename), "r") as f:
            data = json.load(f)
        return data
    else:
        raise HTTPException(status_code=404, detail=f"File {filename} not found")
